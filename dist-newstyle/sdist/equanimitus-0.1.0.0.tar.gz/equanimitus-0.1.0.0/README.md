# equanimitus
